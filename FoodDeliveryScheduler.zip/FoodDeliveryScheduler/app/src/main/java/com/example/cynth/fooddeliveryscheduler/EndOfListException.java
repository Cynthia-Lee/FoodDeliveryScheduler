package com.example.cynth.fooddeliveryscheduler;

/**
 * Created by cynth on 2/19/2018.
 */


public class EndOfListException extends Exception {

}

